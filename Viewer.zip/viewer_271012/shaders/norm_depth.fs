//uniform sampler2D color;
//uniform int z_far;
uniform float fFarClipPlane;
uniform sampler2D smp_color;
varying vec2 Texcoord;
void main(void)
{

   float z_far = fFarClipPlane;

   float z = ((gl_FragCoord.z / gl_FragCoord.w) / z_far)+0.01 ;//+0.01 ;
   float alpha = texture2D(smp_color,Texcoord).w;
   
   if (alpha <0.5)
   {
   discard;
   }
   
   gl_FragColor = vec4(normalize(dFdx((z+1)/2))+0.5, normalize(dFdy((z+1)/2))+0.5, 0, z);
}
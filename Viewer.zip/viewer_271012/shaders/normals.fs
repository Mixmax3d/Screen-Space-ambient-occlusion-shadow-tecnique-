varying vec2 TexCoord;
varying vec3 norm;

void main( void )
{
   vec4 color = vec4( 0.0, 0.0, 0.0, 0.0 );
   

   color.xyz = norm;
  /* 
   float n = 0.1; // camera z near
   float f = 1000.0; // camera z far
   float z = gl_FragCoord.z;
   float d =  (2.0 * n) / (f + n - z * (f - n));
   
   
   //gl_FragColor = vec4( norm, 1);
	
	gl_FragColor = vec4(d,d,d,1);*/
	
	
   float z = 1.0 - (gl_FragCoord.z / gl_FragCoord.w) / 30.0;
	//gl_FragColor = vec4(z, z, z, 1.0);
	gl_FragColor = vec4(color.xyz,1); 
	
}
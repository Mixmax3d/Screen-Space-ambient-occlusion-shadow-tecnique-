uniform sampler2D Colormap;
//uniform vec2 scale;
//uniform vec2 offset;

void main(void){
 vec2 coords = gl_PointCoord; //* scale + offset;
 vec4 color = texture2D(Colormap,gl_PointCoord);
 if (color.w < 0.5)
 {
 discard;
 }
 gl_FragColor = vec4(color.xyz,1);
 }
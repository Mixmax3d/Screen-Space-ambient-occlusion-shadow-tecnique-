uniform sampler2D color;
uniform sampler2D sky;
uniform sampler2D shaft;

varying vec2 UV;

void main(void)
{

	vec4 env = texture2D( color, UV );
    vec4 sky_c = texture2D( sky, UV );
    vec4 shaft = texture2D( shaft, UV );
    
    float env_a = env.w;
   
    vec4 color_out = sky_c;;
   
    if (env_a < 0.5)
    {
		color_out = env + shaft;
	}
    
    
    gl_FragColor = color_out + shaft;
    //gl_FragColor = shaft;
}
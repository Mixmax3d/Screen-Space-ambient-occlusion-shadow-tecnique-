uniform vec2 lightPositionOnScreen;
uniform sampler2D environment;
uniform sampler2D sky;

varying vec2 UV;

void main(void)
{
   float exposure = 0.0034;
   float decay = 1;
   float density = 0.84;
   float weight = 5.65;
   int NUM_SAMPLES = 75 ;

   vec2 deltaTextCoord = vec2( UV.xy - lightPositionOnScreen.xy );
   vec2 textCoo = UV;
   deltaTextCoord *= 1.0 /  float(NUM_SAMPLES) * density;
   float illuminationDecay = 1.0;
   
   
   for(int i=0; i < NUM_SAMPLES ; i++)
   {
         textCoo -= deltaTextCoord;
         
         vec4 sky_s = texture2D(sky, textCoo );
         vec4 env_s = texture2D(environment, textCoo );
         
         float sky_a = sky_s.a;
         float env_a = env_s.a;
         vec4 sample = vec4(sky_a*env_a);
		
         //vec4 sample = texture2D(environment, textCoo );
         
         sample *= illuminationDecay * weight;
         gl_FragColor += sample;
         illuminationDecay *= decay;
   }
   
   gl_FragColor *= exposure;
  
}
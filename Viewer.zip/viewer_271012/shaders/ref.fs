uniform vec4 fvAmbient;
uniform vec4 fvSpecular;
uniform vec4 fvDiffuse;
uniform float fSpecularPower;

uniform sampler2D color;
uniform sampler2D normal;
uniform samplerCube refl;

varying vec2 Texcoord;
varying vec3 ViewDirection;
varying vec3 LightDirection;

void main( void )
{
   vec3  fvLightDirection = normalize( LightDirection );
   vec3  fvNormal         = normalize( ( texture2D( normal, Texcoord ).xyz * 2.0 ) - 1.0 );
   float fNDotL           = dot( fvNormal, fvLightDirection ); 
   
   vec3  fvReflection     = normalize( ( ( 2.0 * fvNormal ) * fNDotL ) - fvLightDirection ); 
   vec3  fvViewDirection  = normalize( ViewDirection );
   float fRDotV           = max( 0.0, dot( fvReflection, fvViewDirection ) );
   
   vec4  fvBaseColor      = texture2D( color, Texcoord );
   
   vec3 reflVec = reflect(-ViewDirection, fvNormal);
   vec4 reflection = textureCube(refl, reflVec.xyz);   
   
     
   
   vec4  fvTotalAmbient   = fvAmbient * fvBaseColor;//* reflection; 
   vec4  fvTotalDiffuse   = fvDiffuse * fNDotL * fvBaseColor;// * reflection; 
   vec4  fvTotalSpecular  = fvSpecular * ( pow( fRDotV, fSpecularPower ) );
  
   gl_FragColor = ( fvTotalAmbient + fvTotalDiffuse + fvTotalSpecular )* reflection ;
       
}
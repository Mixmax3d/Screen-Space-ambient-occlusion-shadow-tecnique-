uniform sampler2D skyNight;
uniform sampler2D skyDay;
uniform sampler2D skySunset;

//uniform sampler3D skyNoise;
//uniform float fTime0_X;

uniform vec3 lightPos;

varying vec4 Position;
varying vec2 Texcoord;

void main( void )
{

   vec4 night_color =texture2D( skyNight, Texcoord );
   vec4 day_color =texture2D( skyDay, Texcoord );
   vec4 sunset_color =texture2D( skySunset, Texcoord );
   //vec4 noise = texture3D(skyNoise,Position.zyx);
   
   vec4 outColor;



   //vec3 curr_pos = lightPos*cos(fTime0_X/2);
   vec3 curr_pos = (lightPos);
 ///////  
   if ((curr_pos.y >0.2)&&(curr_pos.y <=1))
   {
   outColor = mix(sunset_color,day_color,curr_pos.y);
   }
////////   
   if ((curr_pos.y <-0.2)&&(curr_pos.y >=-1))
   {
   outColor = mix(sunset_color,night_color*night_color,-curr_pos.y);;
   }
/////////   
   if ((curr_pos.y >=-0.2) && (curr_pos.y <=0.2))
   {
   outColor = mix(sunset_color,sunset_color*night_color,-curr_pos.y);
   }

   
   
   //outColor = mix(outColor,noise,outColor);
   float dist = distance(lightPos,Position.xyz);
   dist = (1/dist)*50;
    //gl_FragColor =  (mix(outColor,noise,0.051))*dist;
   gl_FragColor = vec4((outColor*dist).xyz,0.2);
}